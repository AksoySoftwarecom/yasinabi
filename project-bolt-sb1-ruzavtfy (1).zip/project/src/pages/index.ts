export { Home } from './Home/Home';
export { About } from './About/About';
export { Projects } from './Projects/Projects';
export { Contact } from './Contact/Contact';